import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import scipy.stats as st
import pickle

matplotlib.rcParams.update({'font.size': 12})


# 从文件中读取数组数据

# 去冗余方法
def analysis(fileName, labelName,lable):
    data_typeDQN = []
    data_typeDQN_ave = []
    data_Sigma = []
    ave = 240
    dateLen = 11200
    flag = 0
    with open(fileName, 'rb') as file:
        try:
            while flag < dateLen:
                data_typeDQN.append(pickle.load(file))
                flag += 1
        except EOFError:
            pass

    # 求均值
    count = 0
    for i in range(len(data_typeDQN)):
        count = count + data_typeDQN[i]
        if i % ave == 0:
            data_typeDQN_ave.append(count / ave)
            count = 0
    Mu = data_typeDQN_ave
    # 求方差
    count = 0
    j = 0
    for k in range(len(data_typeDQN)):
        if j < len(Mu):
            count = count + ((data_typeDQN[k] - Mu[j]) ** 2) / ave
        if k % ave == 0:
            j += 1
            data_Sigma.append(np.sqrt(count))
            count = 0
    Sigma = data_Sigma

    data = np.random.normal(loc=Mu, scale=Sigma, size=(50, len(Mu)))

    # calculate confidence interval
    low_CI_bound, high_CI_bound = st.t.interval(0.95, len(Mu) - 1,
                                                loc=np.mean(data, 0),
                                                scale=st.sem(data))
    # plot confidence interval
    x = np.arange(0, len(data_typeDQN), ave)
    plt.plot(x, Mu, lable, linewidth=2., label=labelName)
    plt.fill_between(x, low_CI_bound, high_CI_bound, alpha=0.5)
    plt.legend()

typeLabelName = 'CSDQN'
LabelName = 'SDQN'
DQNName = 'DQN'
DuelingName = 'DDQN'
CSDQNLabel = 's--'
SDQNLabel = '*--'
DQNLabel = 'o--'
DDQNLabel = '^--'
# 数据源输入
#-----------------------------
# type_evaluate = 'CSDQN.pkl'
# safe_evaluate = 'SDQN.pkl'
# DQN_evaluate = 'DQN.pkl'
# Dueling_evaluate = 'DDQN.pkl'
# analysis(type_evaluate, typeLabelName)
# analysis(safe_evaluate, LabelName)
# analysis(DQN_evaluate, DQNName)
# analysis(Dueling_evaluate, DuelingName)
#-----------------------------
file = 'train/'
type_train = file+'CSDQN.pkl'
safe_train = file+'SDQN.pkl'
DQN_train = file+'DQN.pkl'
Dueling_train = file+'DDQN.pkl'
analysis(type_train, typeLabelName, CSDQNLabel)
analysis(safe_train, LabelName, SDQNLabel)
analysis(DQN_train, DQNName, DQNLabel)
analysis(Dueling_train, DuelingName, DDQNLabel)
plt.xlabel('round')
plt.ylabel('Score')
plt.savefig(file+'result.png')
plt.show()
