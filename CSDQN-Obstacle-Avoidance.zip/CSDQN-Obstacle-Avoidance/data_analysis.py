import pickle
import matplotlib.pyplot as plt
import numpy as np

# 从文件中读取数组数据
data_DQN = []
data_typeDQN = []
data_DQNave = []
data_typeDQN_ave = []
ave =50
with open('experimental_conclusion/train/DDQN.pkl', 'rb') as file:
    try:
        while True:
            data_DQN.append(pickle.load(file))
    except EOFError:
        pass
    x = np.arange(0, len(data_DQN), ave)

with open('experimental_conclusion/train/DQN.pkl', 'rb') as file:
    try:
        while True:
            data_typeDQN.append(pickle.load(file))
    except EOFError:
        pass
    x1 = np.arange(0, len(data_typeDQN), ave)

# x = np.arange(2000,len(data),1)
count = 0
for i in range(len(data_DQN)):
    count = count + data_DQN[i]
    if i % ave == 0:
        data_DQNave.append(count / ave)
        count = 0

count = 0
for i in range(len(data_typeDQN)):
    count = count + data_typeDQN[i]
    if i % ave == 0:
        data_typeDQN_ave.append(count / ave)
        count = 0

plt.plot(x, data_DQNave, label='ave_score')
plt.plot(x1, data_typeDQN_ave, label='ave_score')
plt.xlabel('round')
plt.ylabel('Score')
plt.show()
