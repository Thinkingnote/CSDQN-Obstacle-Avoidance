import pickle
from dis import dis
from telnetlib import PRAGMA_HEARTBEAT
from turtle import Screen
from charset_normalizer import detect
import random
import numpy as np
import pygame
import time
import math
from utils import scale_image, blit_rotate_center
from obstacle import *

GRASS = scale_image(pygame.image.load("imgs/grass.jpg"), 2.5)
TRACK = scale_image(pygame.image.load("imgs/track_double.png"), 0.3)

TRACK_BORDER = scale_image(pygame.image.load("imgs/track_border1.png"), 0.3)
TRACK_BORDER_MASK = pygame.mask.from_surface(TRACK_BORDER)  # 代表什么意思

FINISH = pygame.image.load("imgs/finish.png")
FINISH_MASK = pygame.mask.from_surface(FINISH)
FINISH_POSITION = (453, 580)
BORDER_WIDTH = 69
CHECK_LENGTH = 200

WHITE_CAR = scale_image(pygame.image.load("imgs/car_white.png"), 0.25)
# CENTER_CAR = scale_image(pygame.image.load("imgs/car_white.png"), 0.05)

WIDTH, HEIGHT = TRACK.get_width(), TRACK.get_height()
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Racing Game!")

FPS = 1000
CENTER_PATH = [(503, 516), (504, 415), (503, 314), (501, 217),
               (470, 144), (411, 93), (325, 74), (237, 96), (180, 147),
               (150, 218), (148, 353), (148, 459), (148, 565), (148, 672),
               (173, 763), (233, 828), (324, 853), (417, 829), (480, 762), (503, 678)]

SMALL_PATH = [(487, 516), (487, 415), (487, 314), (486, 221),
              (460, 155), (403, 105), (325, 84), (244, 108), (193, 156), (167, 221),
              (166, 353), (166, 459), (166, 565), (166, 672),
              (184, 752), (242, 816), (324, 839), (409, 815), (467, 755), (487, 678)]

BIG_PATH = [(521, 516), (521, 415), (521, 314), (516, 212),
            (481, 135), (419, 81), (325, 59), (228, 83), (168, 136), (135, 214),
            (131, 353), (131, 459), (131, 565), (131, 672),
            (159, 772), (225, 838), (324, 864), (425, 839), (495, 768), (519, 678)]


class AbstractCar:
    def __init__(self):
        self.img = self.IMG
        self.vel = 2
        self.angle = 0
        self.x, self.y = self.START_POS  # 车辆起始位置
        self.acceleration = 0

    def rotate(self, angle):
        self.angle += angle

        if self.angle > 180:
            self.angle -= 360
        elif self.angle < -180:
            self.angle += 360

    def draw(self, win):
        blit_rotate_center(win, self.img, (self.x, self.y), self.angle)

    def move_forward(self):
        self.vel = self.vel + self.acceleration
        self.move()

        # print('forward')

    def move(self):  # 修改车辆坐标
        radians = math.radians(self.angle)  # 弧度制
        vertical = math.cos(radians) * self.vel
        horizontal = math.sin(radians) * self.vel

        self.y -= vertical
        self.x -= horizontal

    def collide(self, mask, x=0, y=0):
        car_mask = pygame.mask.from_surface(self.img)
        offset = (int(self.x - x), int(self.y - y))
        poi = mask.overlap(car_mask, offset)
        return poi

    def reset(self):
        self.x, self.y = self.START_POS
        self.angle = 0
        self.vel = 2
        self.acceleration = 0


import matplotlib.pyplot as plt
import collections


class ComputerCar(AbstractCar):
    IMG = WHITE_CAR
    START_POS = (481, 540)

    def __init__(self, center_path=[], small_path=[], big_path=[]):
        super().__init__()
        self.center_path = center_path
        self.small_path = small_path
        self.big_path = big_path
        self.current_centerLine_point = 0
        self.D0 = 0
        self.D = 0
        self.obstacle_direction = -1
        self.current_obstacle = 0
        self.current_obstacle_type = 0
        self.find_obstacle = False
        self.obstacle_car_angle = 0
        self.left_border = 0
        self.right_border = 0
        self.radars = []
        self.obstacle_radars = []
        self.reach = False
        self.total_dis = 0
        self.stepnumble = 0
        self.isexceptional = False
        self.guard = 0
        self.flag = 0
        self.vector_c = (0, 0)
        self.car_rect = (0, 0, 0, 0)
        self.N_rect = (0, 0, 0, 0)
        self.S_rect = (0, 0, 0, 0)
        self.E_rect = (0, 0, 0, 0)
        self.W_rect = (0, 0, 0, 0)
        self.is_finished = False
        self.is_collide = False
        self.cumulated_rewards = 0
        self.__calculate_x_y()
        self.direc = 0  # for pid control
        self.obstacle_list = []
        self.obstacle_mask_list = []
        self.obstacle_position = []
        self.obstacle_width = 0
        self.obstacle_height = 0

    def generate_obstacle(self):
        # 构建随机位置
        obstacle1_positionx_list = [477, 513]
        obstacle1_positiony_list = np.arange(410, 430, 5)
        obstacle2_positionx_list = [477, 513]
        obstacle2_positiony_list = np.arange(230, 300, 5)
        obstacle3_positionx_list = [122, 123]
        obstacle3_positiony_list = np.arange(280, 300, 5)
        obstacle4_positionx_list = [118, 152]
        obstacle4_positiony_list = np.arange(440, 460, 5)
        obstacle5_positionx_list = [122, 156]
        obstacle5_positiony_list = np.arange(610, 650, 5)
        obstacle1_positionx = random.choice(obstacle1_positionx_list)
        obstacle1_positiony = random.choice(obstacle1_positiony_list)
        obstacle2_positionx = random.choice(obstacle2_positionx_list)
        obstacle2_positiony = random.choice(obstacle2_positiony_list)
        obstacle3_positionx = random.choice(obstacle3_positionx_list)
        obstacle3_positiony = random.choice(obstacle3_positiony_list)
        obstacle4_positionx = random.choice(obstacle4_positionx_list)
        obstacle4_positiony = random.choice(obstacle4_positiony_list)
        obstacle5_positionx = random.choice(obstacle5_positionx_list)
        obstacle5_positiony = random.choice(obstacle5_positiony_list)
        obstacle_position = [(obstacle1_positionx, obstacle1_positiony), (obstacle2_positionx, obstacle2_positiony),
                             (obstacle3_positionx, obstacle3_positiony), (obstacle4_positionx, obstacle4_positiony),
                             (obstacle5_positionx, obstacle5_positiony)]
        self.obstacle_position = obstacle_position

        # 构建随机障碍物
        obstacle1 = ObstacleCar(WIN, self.obstacle_position[0], 0)
        obstacle2 = ObstaclePerson(WIN, self.obstacle_position[1], 0)
        obstacle3 = ObstacleAnimal(WIN, self.obstacle_position[2], 180)
        obstacle4 = ObstacleTruck(WIN, self.obstacle_position[3], 180)
        obstacle5 = ObstacleCar(WIN, self.obstacle_position[4], 180)
        obstacle_list = [obstacle1, obstacle2, obstacle3, obstacle4, obstacle5]
        obstacle_mask_list = [pygame.mask.from_surface(obstacle1.IMG),
                              pygame.mask.from_surface(obstacle2.IMG),
                              pygame.mask.from_surface(obstacle3.IMG),
                              pygame.mask.from_surface(obstacle4.IMG),
                              pygame.mask.from_surface(obstacle5.IMG)
                              ]
        self.obstacle_list = obstacle_list
        self.obstacle_mask_list = obstacle_mask_list

        self.obstacle_width = obstacle1.IMG.get_width()
        self.obstacle_height = obstacle1.IMG.get_height()

    def generate_evaluation(self, scene):
        evaluate_position_list = [[(513, 430), (510, 210), (122, 310), (118, 450), (122, 630)],
                                  [(513, 430), (463, 210), (122, 310), (118, 450), (156, 630)],
                                  [(513, 430), (463, 210), (122, 310), (152, 450), (156, 630)],
                                  [(477, 430), (463, 210), (160, 310), (160, 450), (156, 630)],
                                  [(477, 430), (510, 210), (160, 310), (156, 450), (122, 630)],
                                  [(477, 430), (510, 210), (160, 310), (122, 450), (122, 630)],
                                  [(477, 430), (463, 210), (160, 310), (122, 450), (156, 630)],
                                  [(513, 430), (510, 210), (122, 310), (156, 450), (122, 630)]
                                  ]
        # self.obstacle_position = random.choice(evaluate_position_list)
        self.obstacle_position = evaluate_position_list[scene]
        # 构建随机障碍物
        obstacle1 = ObstacleCar(WIN, self.obstacle_position[0], 0)
        obstacle2 = ObstaclePerson(WIN, self.obstacle_position[1], 0)
        obstacle3 = ObstacleAnimal(WIN, self.obstacle_position[2], 180)
        obstacle4 = ObstacleTruck(WIN, self.obstacle_position[3], 180)
        obstacle5 = ObstacleCar(WIN, self.obstacle_position[4], 180)
        obstacle_list = [obstacle1, obstacle2, obstacle3, obstacle4, obstacle5]
        obstacle_mask_list = [pygame.mask.from_surface(obstacle1.IMG),
                              pygame.mask.from_surface(obstacle2.IMG),
                              pygame.mask.from_surface(obstacle3.IMG),
                              pygame.mask.from_surface(obstacle4.IMG),
                              pygame.mask.from_surface(obstacle5.IMG),
                              ]
        self.obstacle_list = obstacle_list
        self.obstacle_mask_list = obstacle_mask_list

        self.obstacle_width = obstacle1.IMG.get_width()
        self.obstacle_height = obstacle1.IMG.get_height()

    def __calculate_x_y(self):
        self.cx = self.x + self.img.get_width() / 2  # 指中心坐标center
        self.cy = self.y + self.img.get_height() / 2

    def __calculate_dist(self):

        ########### calculate the deviation of the car from center line ###########
        A_x, A_y = self.center_path[self.current_centerLine_point - 1]
        B_x, B_y = self.center_path[self.current_centerLine_point]
        C_x = self.cx
        C_y = self.cy
        D_x, D_y = self.obstacle_position[self.current_obstacle]

        # vector b
        db_x = C_x - A_x
        db_y = C_y - A_y

        # vector c
        dc_x = B_x - A_x
        dc_y = B_y - A_y
        self.vector_c = (dc_x, dc_y)

        # vector d
        dd_x = D_x - A_x
        dd_y = D_y - A_y

        cross_prdct = db_x * dc_y - db_y * dc_x  # 表示向量的叉积
        if cross_prdct > 0:  # 左侧
            direction = 1
        elif cross_prdct == 0:  # 直行
            direction = 0
        else:
            direction = -1  # 右侧
        self.direc = direction

        # TODO 待验证---------------
        if direction <= 0:  # 在大圈
            # print("在大圈，走大圈规则！！！")
            bigA_x, bigA_y = self.big_path[self.current_centerLine_point - 1]
            bigB_x, bigB_y = self.big_path[self.current_centerLine_point]
            # vector target_target
            tt_x = bigB_x - bigA_x
            tt_y = bigB_y - bigA_y

            # vector target_car
            tc_x = C_x - bigA_x
            tc_y = C_y - bigA_y
            # dc_x ——>tt_x   dc_y——>tt_y  db_x——>tc_x    db_y——>tc_y
            # angle of vector target_target and target_car
            target_target = math.sqrt(tt_x ** 2 + tt_y ** 2)
            target_car = math.sqrt(tc_x ** 2 + tc_y ** 2)
            theta = math.acos((tt_x * tc_x + tt_y * tc_y) / (target_target * target_car))
            # deviation
            dev = abs(target_car * math.sin(theta))
            ############### calculate sideslip angle beta ##################
            # angle between the Frenet and the ground
            # let vector C to be the axis S of the Frenet
            if tt_y != 0:
                phi = math.atan(tt_x / tt_y) * 180 / math.pi
                if tt_y < 0:
                    phi = phi
                elif tt_x < 0:
                    phi = 180 - abs(phi)
                else:
                    phi = -180 + abs(phi)
            else:
                if tt_x < 0:
                    phi = 90
                else:
                    phi = -90

            # beta = self.angle - phi
            # print(phi, self.angle, dc_x,dc_y)
            beta = self.angle - phi
            if (beta > 180) or (beta < -180):
                if phi >= 0:
                    beta = 360 - abs(beta)
                else:
                    beta = abs(beta) - 360
        else:  # 在小圈
            # print("在小圈，走小圈规则！！！")
            smallA_x, smallA_y = self.small_path[self.current_centerLine_point - 1]
            smallB_x, smallB_y = self.small_path[self.current_centerLine_point]
            # vector target_target
            tt_x = smallB_x - smallA_x
            tt_y = smallB_y - smallA_y

            # vector target_car
            tc_x = C_x - smallA_x
            tc_y = C_y - smallA_y
            # dc_x ——>tt_x   dc_y——>tt_y  db_x——>tc_x    db_y——>tc_y

            # angle of vector target_target and target_car
            target_target = math.sqrt(tt_x ** 2 + tt_y ** 2)
            target_car = math.sqrt(tc_x ** 2 + tc_y ** 2)
            theta = math.acos((tt_x * tc_x + tt_y * tc_y) / (target_target * target_car))
            # deviation
            dev = abs(target_car * math.sin(theta))
            ############### calculate sideslip angle beta ##################
            # angle between the Frenet and the ground
            # let vector C to be the axis S of the Frenet
            if tt_y != 0:
                phi = math.atan(tt_x / tt_y) * 180 / math.pi
                if tt_y < 0:
                    phi = phi
                elif tt_x < 0:
                    phi = 180 - abs(phi)
                else:
                    phi = -180 + abs(phi)
            else:
                if tt_x < 0:
                    phi = 90
                else:
                    phi = -90

            # beta = self.angle - phi
            # print(phi, self.angle, dc_x,dc_y)
            beta = self.angle - phi
            if (beta > 180) or (beta < -180):
                if phi >= 0:
                    beta = 360 - abs(beta)
                else:
                    beta = abs(beta) - 360

        #################################################################
        return beta, dev, direction  # 表示在车道线的左侧右侧或中间

    all_observation = []

    def __get_observation(self, beta, dev, direction):
        # 检测下一个障碍物
        self.update_obstacle_point()
        # 获取障碍物类型
        self.get_obstacle_type()

        OB_x, OB_y = self.obstacle_position[self.current_obstacle]
        # 将其更新为中心点坐标
        OB_x = OB_x + self.obstacle_list[self.current_obstacle].IMG.get_width() / 2
        OB_y = OB_y + self.obstacle_list[self.current_obstacle].IMG.get_height() / 2

        dd_x = OB_x - self.cx
        dd_y = OB_y - self.cy
        # get border
        dc_x, dc_y = self.vector_c
        c = math.sqrt(dc_x ** 2 + dc_y ** 2)
        carline_angle = self.angle - beta
        self.left_border = self.check_border(self.cx, self.cy, carline_angle, 180, radar=True)
        self.right_border = self.check_border(self.cx, self.cy, carline_angle, 0, radar=True)
        # 计算横向距离和纵向距离
        o = math.sqrt(dd_x ** 2 + dd_y ** 2)
        carline_and_obstacle_angle = math.acos((dc_x * dd_x + dc_y * dd_y) / (c * o))
        # TODO 修改检测障碍物机制
        # 未发现障碍物或者障碍物为红绿灯，就要检测
        if not self.find_obstacle or self.current_obstacle_type == 0:
            self.check_obstacle()
        if self.find_obstacle:
            obstacle_left_border = self.check_border(OB_x, OB_y, self.obstacle_car_angle, 180)
            la = abs(self.left_border - obstacle_left_border)
            lo = math.sqrt(dd_x ** 2 + dd_y ** 2) * math.cos(carline_and_obstacle_angle)
            self.obstacle_direction = self.get_obstacle_direction()

        else:
            la = BORDER_WIDTH
            lo = 200
            self.obstacle_direction = 0  # 代表没有障碍物
        # print("obstacle_direction:", obstacle_direction, "la:", la, "lo:", lo, "left_border:", left_border, "right_border:", right_border, "beta:", beta, "dev:", dev, "direction:", direction,
        #       "vel:", self.vel, "current_obstacle:", self.current_obstacle, "current_centerLine_point:", self.current_centerLine_point)
        # print("current_obstacle:", self.current_obstacle, "current_obstacle_type:", self.current_obstacle_type, "direc:", self.direc)
        return [self.current_obstacle_type, la, lo, self.obstacle_direction, self.left_border, self.right_border, beta,
                dev, direction]

    all_rewards = [[], [], [], [], []]
    total_rewards = []
    reward_count = 0
    total_actions = []

    # define the environment rewards
    def __get_rewards(self):
        beta, dev, direction = self.__calculate_dist()
        observation = self.__get_observation(beta, dev, direction)
        radian_beta = beta * math.pi / 180

        # TODO 待处理更新-------------
        if self.direc <= 0:
            bigA_x, bigA_y = self.big_path[self.current_centerLine_point - 1]
            bigB_x, bigB_y = self.big_path[self.current_centerLine_point]
            D = math.sqrt((bigB_x - bigA_x) ** 2 + (bigB_y - bigA_y) ** 2)
            D0 = math.sqrt((self.cx - bigA_x) ** 2 + (self.cy - bigA_y) ** 2) * math.cos(radian_beta)
        else:
            smallA_x, smallA_y = self.big_path[self.current_centerLine_point - 1]
            smallB_x, smallB_y = self.big_path[self.current_centerLine_point]
            D = math.sqrt((smallB_x - smallA_x) ** 2 + (smallB_y - smallA_y) ** 2)
            D0 = math.sqrt((self.cx - smallA_x) ** 2 + (self.cy - smallA_y) ** 2) * math.cos(radian_beta)
        reward2 = 2 * D / D0
        self.D0 = D0
        self.D = D
        # print("D:",D,"D0:",D0)

        # reward4 = math.cos((self.vel-4)*math.pi/18)

        la = observation[0]
        lo = observation[1]

        if self.direc == -1:  # 大圈
            reward_border = -np.exp(-self.right_border / 4)
        else:
            reward_border = -np.exp(-self.left_border / 4)
        max_width = 60
        # reward5 = weight * math.sqrt(la**2 + lo**2) / max_distance
        if self.direc == self.obstacle_direction:  # 风险
            reward1 = 0
            reward_dev = 0
            if self.current_obstacle_type == 1:
                reward_obstacle = 1 / 2 * self.current_obstacle_type * (
                        1 - np.power(1.1, -la) + 1 - np.power(1.03, -lo))
            elif self.current_obstacle_type == 2 or self.current_obstacle_type == 4:
                reward_obstacle = 1 / 2 * self.current_obstacle_type * (
                        1 - np.power(1.1, -la) + 1 - np.power(1.02, -lo))
            elif self.current_obstacle_type == 3:
                reward_obstacle = 1 / 2 * self.current_obstacle_type * (
                        1 - np.power(1.1, -la) + 1 - np.power(1.01, -lo))
            else:
                # 此处是处理类型为0的基于规则的奖励函数，还没确定，因为训练用不上之后有需要再确定
                reward_obstacle = self.current_obstacle_type

        else:
            # reward1 = math.cos(radian_beta)
            reward1 = 1 - 0.05 * abs(beta)
            reward_dev = np.exp(-dev / 2)
            # reward_obstacle = self.current_obstacle_type
            reward_obstacle = self.current_obstacle_type
        max_dis = 2600
        reward_dis = np.power(5, self.total_dis / max_dis) / 5

        reward_collision = 0
        if self.is_collide:
            reward_collision = -np.power(1 / 5, self.total_dis / max_dis) * 30
        # rewards = reward_obstacle
        rewards = reward_dev + reward_border + reward_obstacle + reward_dis + reward_collision
        # self.all_rewards[0].append(reward_dev)
        # self.all_rewards[1].append(reward_border)
        # self.all_rewards[2].append(reward_obstacle)
        # self.all_rewards[3].append(reward_dis)
        # self.all_rewards[4].append(reward_collision)
        # self.total_rewards.append(rewards)
        # self.reward_count += 1
        # print("reward_dev:",reward_dev," reward_border:",reward_border, " reward_obstacle:",reward_obstacle, " reward_dis:",reward_dis, " reward_collision:",reward_collision)
        # print("reward1:", reward1, "reward3:", reward3, " reward5:", reward5, " la", la, " rewards:", rewards)
        if self.isexceptional:
            with open('score_abnormal_reward.txt', 'a') as file:
                all_reward = ["step:", self.stepnumble, "   total_reward:", rewards, "   reward_dev:", reward_dev,
                              "   reward_border:", reward_border, "   reward_obstacle:", reward_obstacle,
                              "   reward_dis:", reward_dis, "   reward_collision:", reward_collision, "   la:", la,
                              "   lo:", lo]
                for item in all_reward:
                    file.write(str(item))
                file.write("\n")

        # if self.reward_count % 100 == 0:
        #     plt.subplot(1, 2, 1)
        #     for item in self.all_rewards:
        #         j = np.arange(len(self.all_rewards[0]))
        #         plt.plot(j, item)
        #
        #     plt.legend(['reward_dev', "reward_border:", " reward_obstacle:", " reward_dis:", 'reward_collision'])
        #
        #     plt.subplot(1, 2, 2)
        #     plt.plot([i for i in range(len(self.total_rewards))], self.total_rewards)
        #
        #     plt.show()
        #     time.sleep(5)
        if self.is_finished:
            rewards = 30

        return rewards, observation

    def count_rewards(self):
        pass

    def exceptional(self, stepnumble, score):
        self.stepnumble = stepnumble
        if score < -1000:
            self.isexceptional = True
        else:
            self.isexceptional = False

    def step(self, keys):
        # print(f'selected key: {keys}')
        # self.total_actions.append(keys)
        # if self.reward_count % 10 == 0:
        #     count = {}
        #     for item in self.total_actions:
        #         if item in count:
        #             count[item] += 1
        #         else:
        #             count[item] = 1
        #     x = [k for k in count.keys()]
        #     y = [count[k] for k in x]
        #     # print(x, y)
        #     plt.bar(x, y)
        #     # plt.show()
        # 角度
        if keys == 0:
            angle = -2
            self.rotate(angle)
            self.move()
        if keys == 1:
            angle = -1
            self.rotate(angle)
            self.move()
        if keys == 2:
            angle = 0
            self.rotate(angle)
            self.move()
        if keys == 3:
            angle = 1
            self.rotate(angle)
            self.move()
        if keys == 4:
            angle = 2
            self.rotate(angle)
            self.move()
        # 速度
        if keys == 5:
            self.acceleration += -0.2
            self.move_forward()
        if keys == 6:
            self.acceleration += -0.1
            self.move_forward()
        if keys == 7:
            self.acceleration += 0
            self.move_forward()
        if keys == 8:
            self.acceleration += 0.1
            self.move_forward()
        if keys == 9:
            self.acceleration += 0.2
            self.move_forward()

        self.__handle_collision()

        reward, observation = self.__get_rewards()
        self.cumulated_rewards += reward

        # 结束条件
        if self.is_finished:
            done = True
        elif self.is_collide:
            done = True
        # elif self.vel<=0:
        #     done = True
        else:
            done = False

        # print(self.__sensor(34,24,4))
        # print('reward: ' + str(self.__get_rewards()))
        return (observation, reward, done)  # 此处就是观测值 direction表示在两个目标点所连成线的哪一侧？1：代表右侧 0：代表线上


    def __handle_collision(self):
        # is collided 检测车辆与边界
        if self.collide(TRACK_BORDER_MASK) != None:
            self.is_collide = True
            # self.bounce()
            return
        else:
            self.is_collide = False

        # is collided 检测车辆与其他障碍物
        i = 0
        for obstacle_mask in self.obstacle_mask_list:
            x, y = self.obstacle_position[i]
            i = i + 1
            if self.collide(obstacle_mask, x, y) != None:
                self.is_collide = True
                # self.bounce()
                break
            else:
                self.is_collide = False

        player_finish_poi_collide = self.collide(
            FINISH_MASK, *FINISH_POSITION)
        if player_finish_poi_collide != None:
            self.reset()
            self.is_finished = True

    def bounce(self):
        self.vel = -0.7 * self.vel
        self.move()
        self.vel = 2

    def update_path_point(self):  # 确定小车当前在哪两个红点位置之间
        # if self.current_centerLine_point >= len(self.center_path) - 1:
        # center_target = self.center_path[self.current_centerLine_point]
        # rect = pygame.Rect(
        #     self.x - 30, self.y - 10, self.img.get_width() + 60, self.img.get_height() + 20)
        # print(self.car_rect,self.current_centerLine_point)
        # if rect.collidepoint(*center_target): #星号（*）表示解包操作符（unpacking operator），它可以将一个可迭代对象解包为单独的参数。
        # print("self.D:",self.D,"  self.D0:",self.D0)
        if self.D0 > self.D:
            self.current_centerLine_point += 1
            self.reach = True
        else:
            self.reach = False
        if self.current_centerLine_point >= len(self.center_path):
            self.current_centerLine_point = 0
            return

    def update_obstacle_point(self):
        OB_x, OB_y = self.obstacle_position[self.current_obstacle]
        CB_x = OB_x + self.obstacle_width / 2
        CB_y = OB_y + self.obstacle_height / 2
        if self.current_obstacle_type == 3:
            check_range = [20, 40]
        else:
            check_range = [10, 20]
        rect = pygame.Rect(
            self.x - 50, self.y - check_range[0], self.img.get_width() + 100, self.img.get_height() + check_range[1])
        # self.x - 50, self.y - 10, self.img.get_width() + 100, self.img.get_height() + 20)
        self.car_rect = ((rect[0], rect[1]), (rect[2], rect[3]))  # 包围车辆的那一条绿线
        if rect.collidepoint(CB_x, CB_y):  # 星号（*）表示解包操作符（unpacking operator），它可以将一个可迭代对象解包为单独的参数。
            self.guard = 1
            self.flag = 1
        else:
            self.guard = 0
        if self.guard == 0 and self.flag == 1:
            self.current_obstacle += 1
            self.find_obstacle = False
            self.flag = 0
        if self.current_obstacle >= len(self.obstacle_position):
            self.current_obstacle = 0
            return

    def check_border(self, position_x, position_y, angle, degree,
                     radar=False):  # 该方法获取的是预测2个方向边界与当前车的距离，self.radars是边界点和边界点到车辆中心的距离
        length = 0
        x = int(position_x + math.cos(math.radians(360 - (angle + degree))) * length)  # 360-（当前角度+预测角度）
        y = int(position_y + math.sin(math.radians(360 - (angle + degree))) * length)

        # While We Don't Hit BORDER_COLOR AND length < 300 (just a max) -> go further and further

        while not TRACK_BORDER_MASK.get_at((x, y)):  # 到了边界就结束
            length = length + 1
            x = int(position_x + math.cos(math.radians(360 - (angle + degree))) * length)
            y = int(position_y + math.sin(math.radians(360 - (angle + degree))) * length)

        # Calculate Distance To Border And Append To Radars List
        dist = int(math.sqrt(math.pow(x - position_x, 2) + math.pow(y - position_y, 2)))
        if radar:
            self.radars.append([(x, y), dist])
        return dist

    # TODO 待完善
    def check_obstacle(self):
        obstacle_car_angle = 0
        # 设置障碍物的rect
        obstacle_surface = self.obstacle_mask_list[self.current_obstacle].to_surface()
        obstacle_rect = obstacle_surface.get_rect()
        obstacle_rect.x = self.obstacle_position[self.current_obstacle][0]
        obstacle_rect.y = self.obstacle_position[self.current_obstacle][1]
        # pygame.draw.rect(WIN, (0, 255, 0), obstacle_rect)
        for degree in range(26, 159, 8):  # 由于角度是从x轴方向计算的，所以对于本场景需要角度+90
            # degree = degree + 90
            length = 0
            x = int(self.cx + math.cos(math.radians(360 - (self.angle + degree))) * length)  # 360-（当前角度+预测角度）
            y = int(self.cy + math.sin(math.radians(360 - (self.angle + degree))) * length)
            while (not TRACK_BORDER_MASK.get_at((x, y))) and length < CHECK_LENGTH:

                if obstacle_rect.collidepoint((x, y)):
                    if self.current_obstacle_type != 0:  # 保证障碍物是有角度的
                        obstacle_object = self.obstacle_list[self.current_obstacle]
                        self.obstacle_car_angle = obstacle_object.angle
                    self.find_obstacle = True
                    break
                length = length + 1
                x = int(self.cx + math.cos(math.radians(360 - (self.angle + degree))) * length)
                y = int(self.cy + math.sin(math.radians(360 - (self.angle + degree))) * length)
            # Calculate Distance To Border And Append To Radars List
            dist = int(math.sqrt(math.pow(x - self.cx, 2) + math.pow(y - self.cy, 2)))
            self.obstacle_radars.append([(x, y), dist])

    def get_obstacle_direction(self):
        A_x, A_y = self.center_path[self.current_centerLine_point - 1]
        D_x, D_y = self.obstacle_position[self.current_obstacle]
        # vector c
        dc_x, dc_y = self.vector_c

        # vector d
        dd_x = D_x - A_x
        dd_y = D_y - A_y
        # 代表前两个障碍物
        if self.current_obstacle < 2:
            cross_obstacle = dd_x * dc_y - dd_y * dc_x
        else:
            C10_x, C10_y = self.center_path[10]
            C11_x, C11_y = self.center_path[11]
            # 中心点10和11的向量
            c_x = C11_x - C10_x
            c_y = C11_y - C10_y
            dd_x = D_x - C10_x
            dd_y = D_y - C10_y
            cross_obstacle = dd_x * c_y - dd_y * c_x
        if cross_obstacle > 0:  # 左侧
            obstacle_direction = 1
        else:
            obstacle_direction = -1  # 右侧
        return obstacle_direction

    # TODO 先执行这个感觉不太好
    def get_obstacle_type(self):
        if isinstance(self.obstacle_list[self.current_obstacle], list):
            # light
            self.current_obstacle_type = 1
        else:
            self.current_obstacle_type = self.obstacle_list[self.current_obstacle].ob_type
        # print(f"current_obstacle_type:{self.current_obstacle_type}    current_obstacle:{self.current_obstacle}")

    def get_la_lo(self):
        pass

    def move(self):
        self.update_path_point()
        super().move()
        self.total_dis += self.vel

    def reset(self):
        self.is_finished = False
        self.current_centerLine_point = 0
        self.current_obstacle = 0
        self.cumulated_rewards = 0
        self.obstacle_direction = -1
        self.find_obstacle = False
        self.total_dis = 0
        self.guard = 0
        self.flag = 0
        self.total_rewards = []
        self.all_rewards = [[], [], [], [], []]
        self.reward_count = 0
        self.total_actions = []

        super().reset()
        return np.array([0, 0, 0, 0, 0, 0, 0, 0, 0])

    def draw_points(self, win):
        # for point in self.center_path:
        #     pygame.draw.circle(win, (255, 0, 0), point, 5)
        # for point in self.big_path:
        #     pygame.draw.circle(win, (0, 255, 0), point, 5)
        # for point in self.small_path:
        #     pygame.draw.circle(win, (0, 255, 0), point, 5)
        self.__calculate_x_y()
        # pygame.draw.circle(win, (255, 0, 0), (self.cx, self.cy), 2)

    def draw_car_rect(self, win):
        pygame.draw.rect(win, (0, 255, 0), self.car_rect, 1)
        # sensor rects
        pygame.draw.rect(win, (0, 0, 255), self.N_rect, 1)
        pygame.draw.rect(win, (0, 0, 255), self.S_rect, 1)
        pygame.draw.rect(win, (0, 0, 255), self.E_rect, 1)
        pygame.draw.rect(win, (0, 0, 255), self.W_rect, 1)

    def draw_radar(self, screen):
        # 画的是车辆检测边界的两条线
        for radar in self.radars:
            position = radar[0]
            pygame.draw.line(screen, (0, 255, 0), (self.cx, self.cy), position, 1)  # 画2条绿线的
            pygame.draw.circle(screen, (0, 255, 0), position, 5)  # 画线头圆点的
        self.radars = []

        for obstacle_radar in self.obstacle_radars:
            position = obstacle_radar[0]
            pygame.draw.line(screen, (0, 255, 0), (self.cx, self.cy), position, 1)  # 画5条绿线的
            pygame.draw.circle(screen, (0, 255, 0), position, 5)  # 画线头圆点的
        self.obstacle_radars = []

    def draw_obstacle(self):  # 画的是障碍物
        for obstacle in self.obstacle_list:
            obstacle.draw()

    def draw(self, win):
        super().draw(win)
        self.draw_points(win)
        # self.draw_car_rect(win)
        self.draw_radar(win)
        self.draw_obstacle()


def draw(win, images, player_car):
    for img, pos in images:
        win.blit(img, pos)

    player_car.draw(win)
    pygame.display.update()
