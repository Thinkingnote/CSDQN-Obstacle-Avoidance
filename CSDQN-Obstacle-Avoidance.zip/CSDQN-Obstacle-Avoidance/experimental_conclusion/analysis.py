import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import scipy.stats as st
import pickle

matplotlib.rcParams.update({'font.size': 12})


# 从文件中读取数组数据
file = 'safe_evaluate/'
type_evaluate = file+'CSDQN.pkl'
safe_evaluate = file+'SDQN.pkl'
DQN_evaluate = file+'DQN.pkl'
Dueling_evaluate = file+'DDQN.pkl'

data_typeDQN = []
data_typeDQN_ave = []
data_Sigma = []
flag = 0
result = 0
with open(type_evaluate, 'rb') as file:
    try:
        while flag < 8:
            data_typeDQN.append(pickle.load(file))
            flag += 1

    except EOFError:
        pass
print(len(data_typeDQN))
for i in range(0, len(data_typeDQN)):
    result += data_typeDQN[i]
print(result/8)
# 数据源输入
# -----------------------------
