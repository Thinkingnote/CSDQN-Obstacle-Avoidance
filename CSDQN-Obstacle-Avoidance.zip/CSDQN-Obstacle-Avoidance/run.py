import matplotlib.pyplot as plt

from autocar import *
from CSDQN import Agent
import torch
import torch as T

if __name__ == '__main__':

    # 网络复原
    net = torch.load('net_model/DDQN_model.pkl')
    net.eval()

    clock = pygame.time.Clock()
    images = [(GRASS, (0, 0)), (TRACK, (0, 0)),
              (FINISH, FINISH_POSITION), (TRACK_BORDER, (0, 0))]

    env = ComputerCar(CENTER_PATH, SMALL_PATH, BIG_PATH)


    combined = False
    scores = []
    pass_num = 0
    fail_num = 0
    pass_rate = 0
    pass_rate_list = []
    n_games = 8
    run = True
    for i in range(n_games):
        score = 0
        distance = 0
        idx = 0
        done = False
        observation = env.reset()
        #evaluation场景
        for j in range(8):
            env.generate_evaluation(j)
        # env.generate_obstacle()
        while not done:
            clock.tick(FPS)
            draw(WIN, images, env)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    break
            if run != True:
                break
            # action = agent.choose_action(observation)
            state = T.tensor([observation])
            state = state.to(torch.float32)
            actions = net.forward(state)
            action = T.argmax(actions).item()
            observation_, reward, done = env.step(action)
            score += reward
            observation = observation_
            if env.total_dis > distance:
                distance = env.total_dis

        with open('experimental_conclusion/distance_evaluate/DQN.pkl', 'ab') as file:
            pickle.dump(distance, file)
        if score > 2100:
            pass_num += 1
        else:
            fail_num += 1
        print(f'通过次数：{pass_num} 失败次数：{fail_num}  行驶距离：{distance}')
        print('episodes: ' + str(i) + '------score: ' + str(score))
        if run != True:
            break
    pygame.quit()
