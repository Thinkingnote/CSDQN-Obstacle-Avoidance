import matplotlib.pyplot as plt

from autocar import *
from CSDQN import Agent
import torch
import pickle
import datetime

if __name__ == '__main__':

    run = True
    clock = pygame.time.Clock()
    images = [(GRASS, (0, 0)), (TRACK, (0, 0)),
              (FINISH, FINISH_POSITION), (TRACK_BORDER, (0, 0))]

    env = ComputerCar(CENTER_PATH, SMALL_PATH, BIG_PATH)
    env.generate_obstacle()
    combined = False
    buffer_size = 50000
    weight = 0

    # TODO: fine tune the parameters
    # -------------------------------
    # gamma: discount factor
    # epsilon: random exploration
    # batch_size:
    # n_actions: number of action space
    # input_dims: number of state space
    # lr: learning rate
    # max_mem_size: size of replay buffer
    # 此处加载初始化模型
    # q_eval = torch.load('net_model/net_max.pkl')
    # q_next = torch.load('net_model/net_max.pkl')
    # agent = Agent(gamma=0.95, epsilon=0, batch_size=100, n_actions=5,
    #               eps_end=0, input_dims=9, lr=0.001,
    #               max_mem_size=buffer_size, combined=combined, q_eval=q_eval, q_next=q_next)
    agent = Agent(gamma=0.95, epsilon=1, batch_size=100, n_actions=5,
                  eps_end=0, input_dims=9, lr=0.001,
                  max_mem_size=buffer_size, combined=combined)

    # TODO:load the agent network weights
    #################################
    # agent.Q_eval.load_state_dict(torch.load('weight_eval.pt'))
    # agent.Q_next.load_state_dict(torch.load('weight_next.pt'))

    # 加载记忆库
    # agent.memory.load_buffer('buffer/2023_6_15/')
    #################################

    scores = []
    max_score = 0
    n_games = 100000
    finish_evaluation = 0
    for i in range(n_games):
        # TODO 重新设计
        if i % 10 == 0:
            env.generate_obstacle()
            temp_epsilon = agent.epsilon
            finish_evaluation = 1
        elif env.is_finished or finish_evaluation == 1:
            env.generate_obstacle()
            finish_evaluation = 0

        score = 0
        idx = 0
        done = False
        # TODO 为什么没有重置障碍物呀
        observation = env.reset()
        agent.memory.group_index = 0

        '''
        observation
        1. beta: sideslip angle (the angle between heading angle of the car and the center line)
        2. deviation: deviation between car and center line
        3. direction: check the car's direction from the center line(1 for left and -1 right) 
        '''

        while not done:
            clock.tick(FPS)
            draw(WIN, images, env)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    break
            if not run:
                break
            action = agent.choose_action(observation)
            # print('  obs: ' + str(observation))
            observation_, reward, done = env.step(action)
            score += reward
            agent.memory.store_transition(observation, action, reward,
                                          observation_, done)
            # agent.memory.group_memory(observation, action, reward,
            #                               observation_, done)
            # 检测环境是否异常
            env.exceptional(i, score)

            observation = observation_
            if idx % 100 == 0:
                agent.learn()
            idx += 1
            # print(observation)
        if score > max_score:
            max_score = score
        #     #TODO 转移
        #     agent.memory.group_transfer(weight)
        #     pass
        print('episodes: ' + str(i) + '------score: ' + str(score), '------max_score: ' + str(max_score))
        if score > 2000:
            model = agent.Q_eval
            torch.save(model, 'net_model/net_max.pkl')
        if (i + 1) % 1000 == 0:
            pass
            # TODO: save the trained network weights
            ######################################
            now = datetime.datetime.now()
            model = agent.Q_eval
            torch.save(model, f'net_model/net_{now.year}_{now.month}_{now.day}_{i}.pkl')
            print("已保存！！")
            # torch.save(agent.Q_eval.state_dict(), 'weight_eval.pt')
            # torch.save(agent.Q_next.state_dict(), 'weight_next.pt')
            agent.memory.save_buffer(f'buffer/2023_9_18')
            ######################################
        # if i % 3000 == 0:
        #     weight += 1
        if not run:
            break
        scores.append(score)
        # if i % 100 == 0:
        #     for j in range(len(scores)):
        #         plt.plot(j, scores[j])
        #     plt.show()
        if i % 10 == 0:
            with open('experimental_conclusion/score_data_evaluate3.pkl', 'ab') as file:
                pickle.dump(score, file)
            # with open('score_reward2.txt', 'a') as file:
            #     file.write(f"第{i}轮分数为：{score} 最大分数为{max_score}")
            #     # file.write(str(score))
            #     file.write("\n")
            # with open('experimental_conclusion/score_typeDistance_evaluate.pkl', 'ab') as file:
            #     pickle.dump(env.total_dis, file)
        else:
            with open('experimental_conclusion/score_data_train3.pkl', 'ab') as file:
                pickle.dump(score, file)
            # with open('experimental_conclusion/score_typeDistance_train.pkl', 'ab') as file:
            #     pickle.dump(env.total_dis, file)
        # avg_score = np.mean(scores[-100:])

    pygame.quit()
