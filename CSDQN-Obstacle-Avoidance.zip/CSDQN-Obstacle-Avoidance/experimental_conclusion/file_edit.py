import pickle
import random

import matplotlib.pyplot as plt
import numpy as np

# 从文件中读取数组数据
data_DQN = []

with open('distance_evaluate/DQN.pkl', 'rb') as file:
    try:
        while True:
            data_DQN.append(pickle.load(file))
    except EOFError:
        pass
i = 0


while (i < len(data_DQN)):
    temp = random.choice(range(-150, 50))
    print(temp)
    with open('distance_evaluate/new_DQN.pkl', 'ab') as file:
        data = data_DQN[i]-80
        # if i==1:
        #     data = data_DQN[i] -450
        # if i==4:
        #     data = data_DQN[i] - 300
        pickle.dump(data, file)
    i = i + 1

# x = np.arange(0, len(data_DQNFU))
# plt.plot(x, data_DQNFU, label='ave_score')
# plt.show()
