import numpy as np


class ReplayMemory:
    def __init__(self, input_dims, max_mem, batch_size, combined=False):
        self.mem_size = max_mem
        self.batch_size = batch_size
        self.mem_cntr = 0
        self.combined = combined
        self.state_memory = np.zeros((self.mem_size, input_dims),
                                     dtype=np.float32)
        self.new_state_memory = np.zeros((self.mem_size, input_dims),
                                         dtype=np.float32)
        self.action_memory = np.zeros(self.mem_size, dtype=np.int32)
        self.reward_memory = np.zeros(self.mem_size, dtype=np.float32)
        self.terminal_memory = np.zeros(self.mem_size, dtype=np.bool)

        self.group_state = np.zeros((self.mem_size, input_dims),
                                     dtype=np.float32)
        self.group_new_state = np.zeros((self.mem_size, input_dims),
                                         dtype=np.float32)
        self.group_action = np.zeros(self.mem_size, dtype=np.int32)
        self.group_reward = np.zeros(self.mem_size, dtype=np.float32)
        self.group_terminal = np.zeros(self.mem_size, dtype=np.bool)
        self.group_index = 0
        self.data_index = 0

    def save_buffer(self, path):
        np.save(path+'/state_memory.npy', self.state_memory)
        np.save(path+'/new_state_memory.npy', self.new_state_memory)
        np.save(path+'/action_memory.npy', self.action_memory)
        np.save(path+'/reward_memory.npy', self.reward_memory)
        np.save(path+'/terminal_memory.npy', self.terminal_memory)

    def load_buffer(self, path):
        self.state_memory = np.load(path + 'state_memory.npy')
        self.new_state_memory = np.load(path + 'new_state_memory.npy')
        self.action_memory = np.load(path + 'action_memory.npy')
        self.reward_memory = np.load(path + 'reward_memory.npy')
        self.terminal_memory = np.load(path + 'terminal_memory.npy')

    def store_transition(self, state, action, reward, state_, terminal):
        index = self.mem_cntr % self.mem_size
        self.state_memory[index] = state
        self.action_memory[index] = action
        self.reward_memory[index] = reward
        self.new_state_memory[index] = state_
        self.terminal_memory[index] = terminal

        self.mem_cntr += 1

    def sample_memory(self):
        offset = 1 if self.combined else 0
        max_mem = min(self.mem_cntr, self.mem_size) - offset
        batch = np.random.choice(max_mem, self.batch_size-offset,
                                 replace=False)
        states = self.state_memory[batch]
        new_states = self.new_state_memory[batch]
        actions = self.action_memory[batch]
        rewards = self.reward_memory[batch]
        terminals = self.terminal_memory[batch]

        if self.combined:
            index = self.mem_cntr % self.mem_size - 1
            last_action = self.action_memory[index]
            last_state = self.state_memory[index]
            last_new_state = self.new_state_memory[index]
            last_reward = self.reward_memory[index]
            last_terminal = self.terminal_memory[index]

            actions = np.append(self.action_memory[batch], last_action)
            states = np.vstack((self.state_memory[batch], last_state))
            new_states = np.vstack((self.new_state_memory[batch],
                                   last_new_state))
            rewards = np.append(self.reward_memory[batch], last_reward)
            terminals = np.append(self.terminal_memory[batch], last_terminal)

        return states, actions, rewards, new_states, terminals

    def is_sufficient(self):
        return self.mem_cntr > self.batch_size

    def memory_reset(self):
        self.mem_cntr = 0

    def group_memory(self, state, action, reward, state_, terminal):
        index = self.group_index
        self.group_state[index] = state
        self.group_action[index] = action
        self.group_reward[index] = reward
        self.group_new_state[index] = state_
        self.group_terminal[index] = terminal

        self.group_index += 1

    def group_transfer(self, weight):
        print("group_index:", self.group_index)
        flag = self.group_index - 10
        for group_index in range(self.group_index):
            if group_index > flag:
                num = weight * 10 * (group_index - flag)
                for item in range(num):
                    state = self.group_state[group_index]
                    action = self.group_action[group_index]
                    reward = self.group_reward[group_index]
                    state_ = self.group_new_state[group_index]
                    terminal = self.group_terminal[group_index]

                    index = self.mem_cntr % self.mem_size
                    self.state_memory[index] = state
                    self.action_memory[index] = action
                    self.reward_memory[index] = reward
                    self.new_state_memory[index] = state_
                    self.terminal_memory[index] = terminal
                    self.mem_cntr += 1
            else:
                state = self.group_state[group_index]
                action = self.group_action[group_index]
                reward = self.group_reward[group_index]
                state_ = self.group_new_state[group_index]
                terminal = self.group_terminal[group_index]

                index = self.mem_cntr % self.mem_size
                self.state_memory[index] = state
                self.action_memory[index] = action
                self.reward_memory[index] = reward
                self.new_state_memory[index] = state_
                self.terminal_memory[index] = terminal
                self.mem_cntr += 1
