import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import scipy.stats as st
import pickle

matplotlib.rcParams.update({'font.size': 12})


# 从文件中读取数组数据

# 去冗余方法
def analysis(fileName, labelName, label):
    data_typeDQN = []
    data_typeDQN_ave = []
    data_Sigma = []
    ave = 8
    dateLen = 200
    flag = 0
    with open(fileName, 'rb') as file:
        try:
            while flag < dateLen:
                data_typeDQN.append(pickle.load(file))
                flag += 1
        except EOFError:
            pass

    # 求均值
    count = 0
    for i in range(1, len(data_typeDQN)):
        count = count + data_typeDQN[i]
        if i % ave == 0:
            data_typeDQN_ave.append(count / ave)
            count = 0
    # plot confidence interval
    x = np.arange(0, len(data_typeDQN)-ave, ave)
    # 画图
    plt.plot(x, data_typeDQN_ave, label, alpha=0.5, linewidth=1, label=labelName)
    plt.legend()


typeLabelName = 'CSDQN'
LabelName = 'SDQN'
DQNName = 'DQN'
DuelingName = 'DDQN'
typeLabel = 'rs--'
safeLabel = 'b*--'
DQNLabel = 'go--'
DuelingLabel = '^--'
# 数据源输入
# -----------------------------
file = 'safe_train/'
type_evaluate = file+'CSDQN.pkl'
safe_evaluate = file+'SDQN.pkl'
DQN_evaluate = file+'DQN.pkl'
Dueling_evaluate = file+'DDQN.pkl'

analysis(type_evaluate, typeLabelName, typeLabel)
analysis(safe_evaluate, LabelName, safeLabel)
analysis(DQN_evaluate, DQNName, DQNLabel)
analysis(Dueling_evaluate, DuelingName,DuelingLabel)
#固定label位置
plt.legend(loc="upper left")
plt.xlabel('round')
plt.ylabel('Score')
plt.savefig(file+'result.png')
plt.show()
