import random

from utils import scale_image, blit_rotate_center
import pygame

LIGHT_POSITION = (112, 600)
ZEBRA_CROSSING_POSITION = (470, 270)
OBSTACLE_POSITION = [(515, 450), (350, 80), (120, 290), (255, 800)]


# 车辆障碍物随机位置取值范围


class ObstacleCar:
    def __init__(self, win, position, angle, ob_type=2):
        self.win = win
        self.position = position
        self.angle = angle
        self.ob_type = ob_type
        car1 = "imgs/car_green.png"
        car2 = "imgs/car_red.png"
        carList = [car1, car2]
        carString = random.choice(carList)
        self.IMG = scale_image(pygame.image.load(carString), 0.25)

    def draw(self):
        blit_rotate_center(self.win, self.IMG, self.position, self.angle)


class ObstacleTruck:
    def __init__(self, win, position, angle, ob_type=3):
        self.win = win
        self.position = position
        self.angle = angle
        self.ob_type = ob_type
        truck1 = "imgs/truck_blue.png"
        truck2 = "imgs/truck_yellow.png"
        truckList = [truck1, truck2]
        truckString = random.choice(truckList)
        self.IMG = scale_image(pygame.image.load(truckString), 0.25)

    def draw(self):
        blit_rotate_center(self.win, self.IMG, self.position, self.angle)


class ObstaclePerson:
    def __init__(self, win, position, angle, ob_type=4):
        self.win = win
        self.position = position
        self.angle = angle
        self.ob_type = ob_type
        motorcycle = "imgs/motorcycle.png"
        bicycle = "imgs/bicycle.png"
        person = "imgs/person.png"
        personList = [person, bicycle, motorcycle]
        personString = random.choice(personList)
        self.IMG = scale_image(pygame.image.load(personString), 0.25)

    def draw(self):
        blit_rotate_center(self.win, self.IMG, self.position, self.angle)


class ObstacleAnimal:
    def __init__(self, win, position, angle, ob_type=1):
        self.win = win
        self.position = position
        self.angle = angle
        self.ob_type = ob_type
        self.IMG = scale_image(pygame.image.load("imgs/dog.png"), 0.25)

    def draw(self):
        blit_rotate_center(self.win, self.IMG, self.position, self.angle)


class ObstacleLight:
    def __init__(self, win, position, light, colour, ob_type=1):
        self.win = win
        self.position = position
        self.Light = scale_image(pygame.image.load(light), 0.3)
        self.ob_type = ob_type
        # 0 red, 1 yellow ,2 green
        self.colour = colour

    def draw(self):
        self.win.blit(self.Light, self.position)


class ObstacleZebraCrossing:
    def __init__(self, win, position, ob_type=0):
        self.win = win
        self.position = position
        self.Cross = scale_image(pygame.image.load("imgs/zebra_crossing.png"), 0.3)
        self.ob_type = ob_type

    def draw(self):
        self.win.blit(self.Cross, self.position)
